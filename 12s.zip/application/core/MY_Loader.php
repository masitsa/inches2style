<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

/* load the MX_Loader class */
require APPPATH."libraries/MX/Loader.php";

class MY_Loader extends MX_Loader {}