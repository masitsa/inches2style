<div class="widget">
                      <!-- Widget title -->
                      <div class="widget-head">
                          <h4 class="pull-left"><i class="icon-calendar"></i>Appointments</h4>
                          <div class="widget-icons pull-right">
                              <a href="#" class="wminimize"><i class="icon-chevron-up"></i></a>
                              <a href="#" class="wclose"><i class="icon-remove"></i></a>
                          </div>
                          <div class="clearfix"></div>
                      </div>
                      <div class="widget-content">
                          <!-- Widget content -->
                          <div class="padd">
                              <!-- Below line produces calendar. I am using FullCalendar plugin. -->
                              <div id="appointments"></div>
                          </div>
                      </div>
                  </div>