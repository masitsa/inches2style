
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Fav and touch icons -->
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo base_url()."assets/themes/tshop/";?>ico/apple-touch-icon-144-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo base_url()."assets/themes/tshop/";?>ico/apple-touch-icon-114-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo base_url()."assets/themes/tshop/";?>ico/apple-touch-icon-72-precomposed.png">
<link rel="apple-touch-icon-precomposed" href="ico/apple-touch-icon-57-precomposed.png">
<link rel="shortcut icon" href="<?php echo base_url()."assets/images/";?>favicon.png">
<title><?php echo $title;?></title>
<!-- Bootstrap core CSS -->
<link href="<?php echo base_url()."assets/themes/tshop/";?>bootstrap/css/bootstrap.css" rel="stylesheet">

<!-- Custom styles for this template -->
<link href="<?php echo base_url()."assets/themes/tshop/";?>css/style.css" rel="stylesheet">

<!-- styles needed by minimalect -->
<link href="<?php echo base_url()."assets/themes/tshop/";?>css/jquery.minimalect.min.css" rel="stylesheet">

<!-- css3 animation effect for this template -->
<link href="<?php echo base_url()."assets/themes/tshop/";?>css/animate.min.css" rel="stylesheet">

<!-- styles needed by carousel slider -->
<link href="<?php echo base_url()."assets/themes/tshop/";?>css/owl.carousel.css" rel="stylesheet">
<link href="<?php echo base_url()."assets/themes/tshop/";?>css/owl.theme.css" rel="stylesheet">

<!-- styles needed by checkRadio -->
<link href="<?php echo base_url()."assets/themes/tshop/";?>css/ion.checkRadio.css" rel="stylesheet">
<link href="<?php echo base_url()."assets/themes/tshop/";?>css/ion.checkRadio.cloudy.css" rel="stylesheet">

<!-- styles needed by mCustomScrollbar -->
<link href="<?php echo base_url()."assets/themes/tshop/";?>css/jquery.mCustomScrollbar.css" rel="stylesheet">



<!-- Just for debugging purposes. -->
<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
<![endif]-->

<!-- include pace script for automatic web page progress bar  -->
<script src="<?php echo base_url()."assets/themes/tshop/";?>js/pace.min.js"></script>
<script type="text/javascript" src="<?php echo base_url()."assets/themes/tshop/";?>js/jquery/1.8.3/jquery.js"></script> 